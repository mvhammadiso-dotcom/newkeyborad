package uz.mros.keyboard

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.TranslateRemoteModel
import java.util.Locale

/** On-demand ML Kit translation language packs. No model is downloaded until the user taps Download. */
class LanguagePacksActivity : Activity() {
    private val manager by lazy { RemoteModelManager.getInstance() }
    private lateinit var list: LinearLayout
    private val bg = 0xFFF2F2F7.toInt()
    private val ink = Color.BLACK
    private val blue = 0xFF0A84FF.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(18, 18, 18, 18) }
        root.addView(TextView(this).apply { text = "Tarjima til paketlari"; textSize = 25f; setTextColor(ink); setPadding(0, 8, 0, 8) })
        root.addView(TextView(this).apply { text = "Faqat tanlagan tillaringiz yuklanadi. Har bir model taxminan 30 MB. Yuklangan paketlar oflayn tarjima uchun ishlaydi."; textSize = 14f; setTextColor(0xFF666666.toInt()); setPadding(0, 0, 0, 14) })
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        render()
    }

    private fun render() {
        list.removeAllViews()
        val codes = TranslateLanguage.getAllLanguages().sortedBy { Locale.forLanguageTag(it).getDisplayName(Locale.getDefault()) }
        manager.getDownloadedModels(TranslateRemoteModel::class.java)
            .addOnSuccessListener { downloaded ->
                list.removeAllViews()
                for (code in codes) {
                    val model = TranslateRemoteModel.Builder(code).build()
                    val installed = downloaded.any { it.language == code }
                    val name = Locale.forLanguageTag(code).getDisplayName(Locale.getDefault()).ifBlank { code }
                    val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(8, 10, 4, 10) }
                    val label = TextView(this).apply { text = "$name  ($code)"; textSize = 15f; setTextColor(ink) }
                    row.addView(label, LinearLayout.LayoutParams(0, -2, 1f))
                    val button = Button(this).apply { text = if (installed) "Oʻchirish" else "Yuklab olish"; isAllCaps = false }
                    button.setOnClickListener {
                        button.isEnabled = false
                        if (installed) {
                            manager.deleteDownloadedModel(model)
                                .addOnSuccessListener { toast("$name paketi oʻchirildi"); render() }
                                .addOnFailureListener { toast("Oʻchirib boʻlmadi: ${it.localizedMessage}"); button.isEnabled = true }
                        } else {
                            val conditions = DownloadConditions.Builder().requireWifi().build()
                            manager.download(model, conditions)
                                .addOnSuccessListener { toast("$name paketi yuklandi"); render() }
                                .addOnFailureListener { error ->
                                    button.isEnabled = true
                                    AlertDialog.Builder(this).setMessage("Yuklab boʻlmadi. Wi-Fi va internetni tekshiring.\n${error.localizedMessage}").setPositiveButton("OK", null).show()
                                }
                        }
                    }
                    row.addView(button)
                    list.addView(row)
                    val divider = View(this).apply { setBackgroundColor(0x223C3C43) }
                    list.addView(divider, LinearLayout.LayoutParams(-1, 1))
                }
            }
            .addOnFailureListener { toast("Paketlar roʻyxatini olib boʻlmadi") }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
