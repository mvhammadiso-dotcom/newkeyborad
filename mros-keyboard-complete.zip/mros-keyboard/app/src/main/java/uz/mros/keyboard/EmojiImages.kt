package uz.mros.keyboard

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/**
 * Google Noto 3D emoji. Only emojis actually shown/used are fetched from Google's CDN.
 * Files are cached in app-private storage; missing/unsupported glyphs fall back to Android's font.
 */
object EmojiImages {
    @Volatile var available = true
        private set

    private var started = false
    private var app: Context? = null
    private val cache = object : LruCache<String, Bitmap>(18 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val pending = HashSet<String>()
    private val executor = Executors.newFixedThreadPool(3)
    private val main = Handler(Looper.getMainLooper())
    private val listeners = ArrayList<() -> Unit>()
    private var notifyPosted = false

    fun init(context: Context) {
        synchronized(this) {
            if (started) return
            started = true
            app = context.applicationContext
            available = true
        }
    }

    /** Unicode codepoints used by Noto's static PNG endpoint. */
    fun keyFor(emoji: String): String = codepoints(emoji).joinToString("-") { it.toString(16) }

    private fun codepoints(emoji: String): List<Int> {
        val result = ArrayList<Int>()
        var i = 0
        while (i < emoji.length) {
            val cp = emoji.codePointAt(i)
            i += Character.charCount(cp)
            if (cp == 0xFE0F || cp == 0xFE0E) continue
            result.add(cp)
        }
        return result
    }

    fun has(emoji: String): Boolean = codepoints(emoji).isNotEmpty()

    fun addListener(l: () -> Unit) {
        synchronized(listeners) { if (l !in listeners) listeners.add(l) }
    }
    fun removeListener(l: () -> Unit) {
        synchronized(listeners) { listeners.remove(l) }
    }

    fun get(emoji: String): Bitmap? {
        val key = keyFor(emoji)
        if (key.isBlank()) return null
        cache.get(key)?.let { return it }
        synchronized(pending) { if (!pending.add(key)) return null }
        executor.execute {
            var bitmap: Bitmap? = null
            try {
                val dir = File(app!!.filesDir, "noto3d").apply { mkdirs() }
                val file = File(dir, "$key.png")
                if (file.exists()) {
                    bitmap = BitmapFactory.decodeFile(file.absolutePath)
                } else {
                    val url = URL("https://fonts.gstatic.com/s/e/noto3demoji/latest/$key/512.png")
                    val connection = (url.openConnection() as HttpURLConnection).apply {
                        connectTimeout = 7000
                        readTimeout = 9000
                        requestMethod = "GET"
                        setRequestProperty("User-Agent", "MROS-Keyboard/1.0")
                    }
                    try {
                        if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                            val bytes = connection.inputStream.use { it.readBytes() }
                            if (bytes.isNotEmpty()) {
                                file.writeBytes(bytes)
                                bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                            }
                        }
                    } finally { connection.disconnect() }
                }
            } catch (_: Exception) {
                // Unsupported emoji, offline, or CDN unavailable: native Android emoji is used.
            }
            bitmap?.let { cache.put(key, it) }
            synchronized(pending) { pending.remove(key) }
            scheduleNotify()
        }
        return null
    }

    private fun scheduleNotify() {
        synchronized(this) { if (notifyPosted) return; notifyPosted = true }
        main.postDelayed({
            synchronized(this) { notifyPosted = false }
            synchronized(listeners) { listeners.toList() }.forEach { it() }
        }, 20L)
    }

    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val dst = RectF()

    fun draw(c: Canvas, emoji: String, cx: Float, cy: Float, size: Float, textPaint: Paint, use3d: Boolean, alpha: Int = 255) {
        if (use3d) {
            val bitmap = get(emoji)
            if (bitmap != null) {
                val side = size * 0.96f
                dst.set(cx - side / 2f, cy - side / 2f, cx + side / 2f, cy + side / 2f)
                bmpPaint.alpha = alpha
                c.drawBitmap(bitmap, null, dst, bmpPaint)
                return
            }
        }
        val old = textPaint.alpha
        if (alpha != 255) textPaint.alpha = alpha
        c.drawText(emoji, cx, cy - (textPaint.descent() + textPaint.ascent()) / 2f, textPaint)
        if (alpha != 255) textPaint.alpha = old
    }
}
