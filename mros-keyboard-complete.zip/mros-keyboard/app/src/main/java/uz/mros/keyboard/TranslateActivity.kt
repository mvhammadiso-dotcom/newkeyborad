package uz.mros.keyboard

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.nl.translate.TranslateLanguage
import java.util.Locale

/** On-device translation; downloads only the source/target models needed for this pair. */
class TranslateActivity : Activity() {
    private lateinit var source: Spinner
    private lateinit var target: Spinner
    private lateinit var input: EditText
    private lateinit var output: TextView
    private lateinit var translate: Button
    private var translator: Translator? = null
    private lateinit var codes: List<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        codes = TranslateLanguage.getAllLanguages().sortedBy { Locale.forLanguageTag(it).getDisplayName(Locale.getDefault()) }
        val names = codes.map { "${Locale.forLanguageTag(it).getDisplayName(Locale.getDefault())} ($it)" }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 18, 18, 18); setBackgroundColor(0xFFF2F2F7.toInt()) }
        root.addView(TextView(this).apply { text = "MROS Translate"; textSize = 27f; setTextColor(Color.BLACK); setPadding(0, 8, 0, 16) })
        source = Spinner(this).also { it.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names); it.setSelection(codes.indexOf("uz").coerceAtLeast(0)) }
        target = Spinner(this).also { it.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names); it.setSelection(codes.indexOf("en").coerceAtLeast(0)) }
        root.addView(TextView(this).apply { text = "Tarjima qilinadigan til"; setTextColor(Color.DKGRAY) }); root.addView(source)
        root.addView(TextView(this).apply { text = "Natija tili"; setTextColor(Color.DKGRAY) }); root.addView(target)
        input = EditText(this).apply { hint = "Matnni kiriting"; minLines = 3; gravity = Gravity.TOP; textSize = 16f }
        root.addView(input, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 14 })
        translate = Button(this).apply { text = "Tarjima qilish"; isAllCaps = false }
        root.addView(translate)
        output = TextView(this).apply { text = "Tarjima shu yerda chiqadi"; textSize = 17f; setTextColor(Color.BLACK); setPadding(4, 18, 4, 18) }
        root.addView(output, LinearLayout.LayoutParams(-1, 0, 1f))
        val copy = Button(this).apply { text = "Natijani nusxalash"; isAllCaps = false }
        root.addView(copy)
        copy.setOnClickListener {
            val text = output.text.toString()
            if (text.isNotBlank() && text != "Tarjima shu yerda chiqadi") {
                getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("MROS Translate", text))
                Toast.makeText(this, "Nusxalandi", Toast.LENGTH_SHORT).show()
            }
        }
        translate.setOnClickListener { performTranslation() }
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
    }

    private fun performTranslation() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) { input.error = "Matn kiriting"; return }
        val from = codes[source.selectedItemPosition]
        val to = codes[target.selectedItemPosition]
        if (from == to) { output.text = text; return }
        translator?.close()
        translator = Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(from).setTargetLanguage(to).build())
        translate.isEnabled = false
        translate.text = "Til paketi tekshirilmoqda…"
        val conditions = DownloadConditions.Builder().requireWifi().build()
        translator!!.downloadModelIfNeeded(conditions)
            .addOnSuccessListener {
                translate.text = "Tarjima qilinmoqda…"
                translator?.translate(text)
                    ?.addOnSuccessListener { result -> output.text = result; translate.text = "Tarjima qilish"; translate.isEnabled = true }
                    ?.addOnFailureListener { fail(it.localizedMessage ?: "Xatolik") }
            }
            .addOnFailureListener { fail("Tarjima paketi yuklanmadi. Wi-Fi va internetni tekshiring. ${it.localizedMessage ?: ""}") }
    }

    private fun fail(message: String) {
        output.text = message
        translate.text = "Tarjima qilish"
        translate.isEnabled = true
    }

    override fun onDestroy() { translator?.close(); translator = null; super.onDestroy() }
}
