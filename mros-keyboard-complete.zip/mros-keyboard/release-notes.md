# MROS Keyboard — til va emoji yangilanishi

- Klaviatura sozlamalariga ko‘plab lotin, kirill va boshqa yozuv tizimlari uchun maketlar qo‘shildi.
- Tarjima tillari Google ML Kit orqali alohida yuklanadi; foydalanilmaydigan modellarni o‘chirish mumkin.
- Google Noto 3D emoji endi kerak bo‘lganda CDN’dan yuklanadi va qurilmada keshlanadi; internet bo‘lmasa tizim emojisi bilan fallback qiladi.
- GitHub Actions uchun APK build/release workflow yangilandi.

**Cheklov:** xitoycha Pinyin, yaponcha Kana/Kanji va koreyscha Hangul kabi kompozitsion IME konvertatsiyasi alohida engine talab qiladi va ushbu versiyada to‘liq yoqilmagan.
