# MROS Klaviatura

Android uchun Gboard'ga o'xshash klaviatura — **Liquid Glass** (shisha) dizaynida, iOS uslubidagi emoji paneli bilan.

## Imkoniyatlar
- Klaviatura tillari: **52 ta til profili va yozuv maketi** (lotin, kirill, yunon, arab, fors, ibroniy, hind, bengal, tay, tamil, telugu, kannada, malayalam, gujarati, panjob, gruzin, arman va boshqalar) — sozlamalardan tanlanadi; bo‘shliqni bosib turib almashtiriladi
- Shisha tugmalar: jele kabi tebranish, suv tomchisi to'lqini, orqadagi rangli yorug'lik, "pop" bo'ladigan harf baloni
- Android 15 da tizimning pastki tugmalari (⌄, klaviatura almashtirish) klaviatura ustiga tushmaydi; "Pastdan masofa" sozlamasi bor
- Uzoq bosish: raqamlar va qo'shimcha harflar (o → oʻ, g → gʻ, е → ё, у → ў, к → қ, г → ғ, х → ҳ ...)
- Shift / CAPS (ikki marta bosish), avtomatik bosh harf, ikki bo'shliq = nuqta
- Bo'shliq tugmasini surib kursorni siljitish, bosib turish — klaviaturalar ro'yxati
- So'z takliflari (o'zbek, rus, ingliz) + siz yozgan so'zlarni o'rganish
- iOS uslubidagi emoji panel: gorizontal varaqlash, bo'limlar, "tez-tez ishlatiladi", **qidiruv** (o'zbek/rus/ingliz so'zlar bilan), **teri rangini tanlash** (emoji ustida bosib turing)
- Bufer (clipboard) tarixi — bir bosishda joylash; yon tomonga surish bilan qadash/qadogʻini bekor qilish, uzoq bosish bilan oʻchirish
- Raqam maydonlari uchun alohida raqam paneli, email/havola maydonlari uchun @ va / tugmalari
- Yorug' / qorong'i / avto mavzu, balandlikni o'zgartirish, tebranish va ovoz sozlamalari

## GitHub orqali APK yig'ish
Har bir `push` dan keyin **Actions** avtomatik APK yig'adi va **Releases** bo'limiga joylaydi.

### Telefondan (kompyutersiz)
1. github.com da yangi repo oching (masalan `mros-keyboard`).
2. **Add file → Create new file**, nomiga `.github/workflows/build.yml` deb yozing va shu fayl mazmunini joylang → *Commit*.
3. **Add file → Upload files** → `mros-keyboard.zip` ni yuklang → *Commit*.
4. **Actions** bo'limida build tugashini kuting (5–8 daqiqa). ZIP avtomatik ochiladi va kod repoga joylanadi.
5. **Releases** bo'limidan `MROS-Klaviatura-...apk` ni yuklab, o'rnating.

### Kompyuterdan
ZIP ichidagi `mros-keyboard` papkasi mazmunini repoga yuklang (`.github` papkasi bilan birga) va push qiling.

## Avtomatik yangilanish
ZIP (yoki kod) GitHub'ga yuklanadi → Actions APK yig'ib, shu repoda Release qiladi →
telefondagi ilova uni o'zi topadi (har 6 soatda va klaviatura ochilganda), Wi-Fi'da o'zi yuklab o'rnatadi
yoki bildirishnoma yuboradi.

- **Repo ochiq bo'lsa** — hech narsa sozlash shart emas.
- **Repo yopiq bo'lsa** — bitta kalit kerak:
  1. GitHub → Settings → Developer settings → Fine-grained tokens → Generate:
     faqat shu repo, ruxsat **Contents: Read-only**.
  2. Repo → Settings → Secrets and variables → Actions → New secret: `UPDATE_TOKEN` = token.
  Token APK ichiga yoziladi — APK'ni boshqalarga tarqatmang.

Birinchi marta (yangilanish funksiyasi bor versiyani) qo'lda o'rnatasiz. Android tizimi birinchi
yangilanishda "O'rnatish"ni so'raydi, keyingilari (Android 12+) so'rovsiz o'tadi.
"Nima yangi" matni `release-notes.md` faylidan olinadi.

## Shaxsiy shrift
Sozlamalar → Shaxsiy shrift → "TTF fayl yuklash". Tanlangan shrift emoji panelida ishlatiladi.

## O'rnatgandan keyin
Ilovani oching → **1. Klaviaturani yoqish** → **2. MROS Klaviaturani tanlash**.

## Google Noto 3D emoji
Emoji paneli Google Noto 3D static PNG CDN manbasidan foydalanadi. Rasm faqat emoji panelda ko‘rsatilganda so‘raladi va ilovaning ichki xotirasida keshlanadi; butun to‘plam APK ichiga qo‘shilmaydi. Internet bo‘lmasa yoki ma’lum emoji CDN’da topilmasa, Android tizim emojisi ko‘rsatiladi. Manba: https://googlefonts.github.io/noto-emoji-files/ .

## Til paketlari va tarjima
**Sozlamalar → Til paketlarini boshqarish** bo‘limida ML Kit qo‘llaydigan tarjima tillaridan faqat keraklilarini yuklab oling yoki o‘chiring. Tarjima modellari qurilmada ishlaydi; tarjima uchun kerakli manba va maqsad til modellari birinchi foydalanishda yuklanadi. Yuklangan juftlik internet bo‘lmaganda ham ishlashi mumkin.

Eslatma: tarjima modellari soni klaviatura yozuv maketlari soni bilan bir xil emas. Xitoycha Pinyin, yaponcha Kana→Kanji va koreyscha Hangul kompozitsiyasi kabi murakkab IME konvertatsiya mexanizmlari bu versiyada hali yo‘q; shu tillarda tarjima mavjud bo‘lishi mumkin, ammo to‘liq mahalliy kiritish mexanizmi deb hisoblanmasin.

## Eslatma
- Emoji panelda Google Noto 3D (internet va kesh mavjud bo‘lsa) yoki tizim uslubida ko‘rinadi. Yuborilgan emoji esa oddiy belgi: matn maydonida va qabul qiluvchida o'sha ilova/qurilma uslubida chiqadi (iPhone'da — Apple emojilari).
- `app/mros-keystore.jks` — yangilanishlar ustidan o'rnatilishi uchun doimiy imzo kaliti. Repo ochiq bo'lsa, kalitni GitHub Secrets'ga ko'chirish tavsiya etiladi.

### On-demand translation language packs

Open **Settings → Til paketlari → Til paketlarini boshqarish** to download only the translation languages you need. Models are managed by Google ML Kit and are downloaded on Wi-Fi. Once installed, translation runs on-device and can work offline. Unneeded models can be removed from the same screen. The **Tarjimon** screen lets you choose source and target languages, translate text, and copy the result.

These are translation models (50+ languages), not keyboard typing layouts. This revision still includes the Uzbek, Russian and English keyboard layouts; additional script-specific typing engines (for example Chinese Pinyin and Japanese Kana/Kanji conversion) are not yet included.
